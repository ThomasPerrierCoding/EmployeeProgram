﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee
{   //  Begin namespace Employee
    class Employee
    {   //  Begin class Employee
        //	Declare and initialize program constants
        const int MINEMPNUM     =  1000;    //  Min employee number
        const int MAXEMPNUM     = 10000;    //  Min employee number
        const int DEFEMPNUM     =  9999;    //  Min employee number
        const double MINHOURS   =     0.0;  //	Min hours employee works
        const double MAXHOURS   =    84.0;  //	Max hours employee works
        const double DEFHOURS   =    40.0;  //	Default hours employee works
        const double MINRATE    =     0.0;  //	Min hourly rate
        const double MAXRATE    =   100.0;  //	Max hourly rate
        const double DEFRATE    =    25.0;  //	Default hourly rate
        const double MAXNONOT   =    40.0;  //	Max straight time hours
        const double OTRATE     =     1.5;  //	Overtime rate

        //	Declare program instance variables
        private string firstName;
        private string middleInit;
        private string lastName;
        private bool isUnion;
        private int empNum;
        private double hoursWorked;
        private double hourlyRate;
        private double grossPay;

        //************************************************
        //	No-arg constructor
        //************************************************

        public Employee()
        {   //  Begin public Employee() No-arg constructor
            firstName   = "UFN";
            middleInit  = "*";
            lastName    = "ULN";
            isUnion     = false;        //	Unnecessary
            empNum      = DEFEMPNUM;
            hoursWorked = DEFHOURS;
            hourlyRate  = DEFRATE;
            grossPay    = calculateGrossPay();
        }   //  End   public Employee() No-arg constructor 

        //************************************************
        //	Full-arg constructor
        //************************************************

        public Employee(string fn, string mi, string ln,
                        bool iu, int en,
                        double hw, double hr)
        {   //  Begin public Employee() Full-arg constructor
            this.firstName      = fn;
            this.middleInit     = mi;
            this.lastName       = ln;
            this.isUnion        = iu;
            this.empNum         = en;
            this.hoursWorked    = hw;
            this.hourlyRate     = hr;
            this.grossPay       = calculateGrossPay();
        }   //  End   public Employee() Full-arg constructor

        //************************************************
        //	firstName getter/setter
        //************************************************

        public string FirstName
        {   //  Begin public string FirstName
            get
            {
                return firstName;
            }
            set
            {
                if (value == "")
                {
                    firstName = "UFN";
                }
                else
                {
                    firstName = value;
                }
             }
        }   //  End   public string FirstName

        //************************************************
        //	middleInit getter/setter
        //************************************************

        public string MiddleInit
        {   //  Begin public string MiddleInit
            get
            {
                return middleInit;
            }
            set
            {
                middleInit = (value == string.Empty) ? "*" : value;
            }
        }   //  End   public string MiddleInit

        //************************************************
        //	lastName getter/setter
        //************************************************

        public string LastName
        {   //  Begin public string LastName
            get
            {
                return lastName;
            }
            set
            {
                lastName = (value != string.Empty) ? value : "ULN";
            }
        }   //  End   public string LastName

        //************************************************
        //	isUnion getter/setter
        //************************************************

        public bool IsUnion
        {   //  Begin public bool IsUnion
            get
            {
                return isUnion;
            }
            set
            {
                isUnion = ((value == true) || (value == false)) ? value : false;
            }
        }   //  End   public bool IsUnion

        //************************************************
        //	empNum getter/setter
        //************************************************

        public int EmpNum
        {   //  Begin public int EmpNum
            get
            {
                return empNum;
            }
            set
            {
                bool result = Int32.TryParse(value.ToString(), out empNum);

                //  Handle non-numeric input
                if (!result)            //  if (result == false)
                {
                    empNum = DEFEMPNUM;
                }
                else if ((empNum < MINEMPNUM) || (empNum > MAXEMPNUM))
                {
                    empNum = DEFEMPNUM;
                }
            }
        }   //  End   public int EmpNum

        //************************************************
        //	hoursWorked getter/setter
        //************************************************

        public double HoursWorked
        {   //  Begin public double HoursWorked
            get
            {
                return hoursWorked;
            }
            set
            {
                bool result = Double.TryParse(value.ToString(), out hoursWorked);

                //  Handle non-numeric input
                if (!result)            //  if (result == false)
                {
                    hoursWorked = DEFHOURS;
                }
                else if ((value < MINHOURS) || (value > MAXHOURS))
                {
                    hoursWorked = DEFHOURS;
                }
                else
                {
                    hoursWorked = value;
                }   //  End   public double HoursWorked
            }
        }

        //************************************************
        //	hourlyRate getter/setter
        //************************************************

        public double HourlyRate
        {   //  Begin public double HourlyRate
            get
            {
                return hourlyRate;
            }
            set
            {
                bool result = Double.TryParse(value.ToString(), out hourlyRate);

                //  Handle non-numeric input
                if (!result)            //  if (result == false)
                {
                    hourlyRate = DEFRATE;
                }
                else if ((value < MINRATE) || (value > MAXRATE))
                {
                    hourlyRate = DEFRATE;
                }
                else
                {
                    hourlyRate = value;
                }
            }
        }   //  End   public double HourlyRate

        //************************************************
        //	calculateGrossPay()
        //************************************************

        public double calculateGrossPay()
        {   //  Begin public double calculateGrossPay()
            if (hoursWorked <= MAXNONOT)
            {
                grossPay = hoursWorked * hourlyRate;
            }
            else
            {
                grossPay = ((MAXNONOT * hourlyRate) +               //	Straight time pay
                           ((hoursWorked - MAXNONOT) * hourlyRate * OTRATE));
            }

            return grossPay;
        }   //  End   public double calculateGrossPay()

        //************************************************
        //	Overridden ToString()
        //************************************************

        public override string ToString()
        {   //  Begin public override string ToString()
            string outputStr = "";

            outputStr += "Employee Name: "      + FirstName                     + " " + 
                                                  MiddleInit                    + " " + 
                                                  LastName                      + "\n";
            outputStr += "Union Status:  "      + IsUnion.ToString()            + "\n";
            outputStr += "Employee Number: "    + EmpNum.ToString()             + "\n";
            outputStr += "Hours Worked: "       + HoursWorked.ToString("f2")    + "\n";
            outputStr += "Hourly Rate: "        + HourlyRate.ToString("c")      + "\n";
            outputStr += "Gross Pay: "          + grossPay.ToString("c")        + "\n";

            return outputStr;
        }   //  End   public override string ToString()

        //************************************************
    }   //  End   class Employee
}   //  End   namespace Employee
