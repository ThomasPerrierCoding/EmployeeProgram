﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Employee
{   //  Begin namespace Employee
    class Program
    {   //  Begin class Program
        static void Main(string[] args)
        {   //  Begin static void Main(string[] args)
            //  Call to No-Arg Constructor
            var blankEmployee00 = new Employee();

            //  Call to getter
            WriteLine("Employee 00:\n" + blankEmployee00);

            //  Call to Full-Arg Constructor
            var goodNoOTEmployee0 = new Employee("Charles", "J", "Corrigan", false, 1000, 84, 100);

            //  Call to getter
            WriteLine("Employee 0:\n" + goodNoOTEmployee0);

            //  Call to No-Arg Constructor
            var goodNoOTEmployee1 = new Employee();

            //  Calls to associated setters
            goodNoOTEmployee1.FirstName     = "Jeffrey";
            goodNoOTEmployee1.MiddleInit    = "P";
            goodNoOTEmployee1.LastName      = "Scott";
            goodNoOTEmployee1.IsUnion       = false;
            goodNoOTEmployee1.EmpNum        = 1111;
            goodNoOTEmployee1.HoursWorked   = 40.0;
            goodNoOTEmployee1.HourlyRate    = 25.0;
            goodNoOTEmployee1.calculateGrossPay();

            //  Call to getter
            WriteLine("Employee 1:\n" + goodNoOTEmployee1);

            //  Call to No-Arg Constructor
            var goodOTEmployee = new Employee();

            //  Calls to associated setters
            goodOTEmployee.FirstName        = "Mary";
            goodOTEmployee.MiddleInit       = "K";
            goodOTEmployee.LastName         = "Jones";
            goodOTEmployee.IsUnion          = true;
            goodOTEmployee.EmpNum           = 2222;
            goodOTEmployee.HoursWorked      = 50.0;
            goodOTEmployee.HourlyRate       = 20.0;
            goodOTEmployee.calculateGrossPay();

            //  Call to getter
            WriteLine("Employee 2:\n" + goodOTEmployee);

            //  Call to No-Arg Constructor
            var badFNEmployee = new Employee();

            //  Calls to associated setters
            badFNEmployee.FirstName         = "";
            badFNEmployee.MiddleInit        = "G";
            badFNEmployee.LastName          = "Wilson";
            badFNEmployee.IsUnion           = true;
            badFNEmployee.EmpNum            = 3333;
            badFNEmployee.HoursWorked       = 45.0;
            badFNEmployee.HourlyRate        = 30.0;
            badFNEmployee.calculateGrossPay();

            //  Call to getter
            WriteLine("Employee 3:\n" + badFNEmployee);

            //  Call to No-Arg Constructor
            var badMIEmployee = new Employee();

            //  Calls to associated setters
            badMIEmployee.FirstName         = "Kiley";
            badMIEmployee.MiddleInit        = "";
            badMIEmployee.LastName          = "Fleming";
            badMIEmployee.IsUnion           = false;
            badMIEmployee.EmpNum            = 4444;
            badMIEmployee.HoursWorked       = 40.0;
            badMIEmployee.HourlyRate        = 40.0;
            badMIEmployee.calculateGrossPay();

            //  Call to getter
            WriteLine("Employee 4:\n" + badMIEmployee);

            //  Call to No-Arg Constructor
            var badLNEmployee               = new Employee();

            //  Calls to associated setters
            badLNEmployee.FirstName         = "John";
            badLNEmployee.MiddleInit        = "J";
            badLNEmployee.LastName          = "";
            badLNEmployee.IsUnion           = true;
            badLNEmployee.EmpNum            = 5555;
            badLNEmployee.HoursWorked       = 10.0;
            badLNEmployee.HourlyRate        = 10.0;
            badLNEmployee.calculateGrossPay();

            //  Call to getter
            WriteLine("Employee 5:\n" + badLNEmployee);

            //  Call to No-Arg Constructor
            var badENEmployee = new Employee();

            //  Calls to associated setters
            badENEmployee.FirstName         = "Mark";
            badENEmployee.MiddleInit        = "B";
            badENEmployee.LastName          = "Bronson";
            badENEmployee.IsUnion           = false;
            badENEmployee.EmpNum            = 66666;
            badENEmployee.HoursWorked       = 10.0;
            badENEmployee.HourlyRate        = 10.0;
            badENEmployee.calculateGrossPay();

            //  Call to getter
            WriteLine("Employee 6:\n" + badENEmployee);

            //  Call to No-Arg Constructor
            var badHWEmployee = new Employee();

            //  Calls to associated setters
            badHWEmployee.FirstName         = "Kelly";
            badHWEmployee.MiddleInit        = "X";
            badHWEmployee.LastName          = "Farnsworth";
            badHWEmployee.IsUnion           = true;
            badHWEmployee.EmpNum            = 7777;
            badHWEmployee.HoursWorked       = -30.0;
            badHWEmployee.HourlyRate        = 10.0;
            badHWEmployee.calculateGrossPay();

            //  Call to getter
            WriteLine("Employee 7:\n" + badHWEmployee);

            //  Call to No-Arg Constructor
            var badHREmployee = new Employee();

            //  Calls to associated setters
            badHREmployee.FirstName = "Cari";
            badHREmployee.MiddleInit = "J";
            badHREmployee.LastName = "Granger";
            badHREmployee.IsUnion = false;
            badHREmployee.EmpNum = 8888;
            badHREmployee.HoursWorked = 50.0;
            badHREmployee.HourlyRate = -10.0;
            badHREmployee.calculateGrossPay();

            //  Call to getter
            WriteLine("Employee 8:\n" + badHREmployee);

            ReadLine();
        }   //  End   static void Main(string[] args)
    }   //  End   class Program
}   //  End   namespace Employee
